import { Col, Divider, Row } from 'antd';
import styles from 'styles/client.module.scss';
import SearchProviderClient from '@/components/client/searchprovider.client';
import ProviderCard from '@/components/client/card/provider.card';


const ClientProviderPage = (props: any) => {
    return (
        <div className={styles["container"]} style={{ marginTop: 20 }}>
            <Row gutter={[20, 20]}>
            <Col span={24}>
                    <SearchProviderClient />
            </Col>
                <Divider />
                <Col span={24}>
                    <ProviderCard
                        showPagination={true}
                    />
                </Col>
            </Row>
        </div>
    )
}

export default ClientProviderPage;