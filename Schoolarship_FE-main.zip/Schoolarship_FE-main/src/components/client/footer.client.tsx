
const Footer = () => {
    return (
        <footer style={{ padding: 15, textAlign: "center" }}>
            {/* <div>Frontend React Typescript - Series Nest.JS Basic &copy; Hỏi Dân IT</div> */}
        </footer>
    )
}

export default Footer;